﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_Negocios_IIP
{
    //EstacionamientoConnectionString
    class ClaseConexion
    {
        public static string Cn = @"Data Source=DESKTOP-JDLKDN3\SQLEXPRESS;Initial Catalog=Estacionamiento;Integrated Security=True";
    }
}
